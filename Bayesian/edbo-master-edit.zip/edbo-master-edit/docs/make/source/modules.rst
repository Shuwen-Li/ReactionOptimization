Bayesian Reaction Optimization
=======================================================

.. toctree::
   :maxdepth: 4

   bro
   objective
   init_scheme
   models
   acq_func
   