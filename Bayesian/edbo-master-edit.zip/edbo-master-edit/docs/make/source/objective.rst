Optimization Objective
=======================================================

.. automodule:: edbo.objective
   :members:
   :special-members:
   :exclude-members: __weakref__, __dict__, __module__
   :member-order: bysource
   