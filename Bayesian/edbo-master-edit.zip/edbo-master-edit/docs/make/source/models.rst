Surrogate Models
=======================================================

.. automodule:: edbo.models
   :members:
   :special-members:
   :exclude-members: __weakref__, __dict__, __module__
   :member-order: bysource
   