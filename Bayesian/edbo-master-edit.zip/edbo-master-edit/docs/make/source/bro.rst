Bayesian Optimization
=======================================================

.. automodule:: edbo.bro
   :members:
   :special-members:
   :exclude-members: __weakref__, __dict__, __module__
   :member-order: bysource
   