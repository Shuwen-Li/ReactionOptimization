Acquisition Functions
=======================================================

.. automodule:: edbo.acq_func
   :members:
   :special-members:
   :exclude-members: __weakref__, __dict__, __module__
   :member-order: bysource
   